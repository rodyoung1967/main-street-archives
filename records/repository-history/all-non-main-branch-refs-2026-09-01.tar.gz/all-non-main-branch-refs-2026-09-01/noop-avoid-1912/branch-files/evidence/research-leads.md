# Research Leads

## RL-001 — Morton, Washington Connection
The 'Larry' in Larry's Kwality Cafe or J. Jager may be connected to restaurant owners or operators from Morton, Washington. Unverified.

## RL-002 — 1919 Construction Date
The 1919 date appears in secondary sources and should be tested against assessor records, Sanborn maps, tax cards, permits, deeds, and city directories.

## RL-003 — Directory Search
Polk directories and Oregon City telephone books may establish year-by-year occupants for 503 and 505 Main. This is especially important for separating Kwality Cafe / New Kwality Cafe / Larry's Kwality Cafe, The Wheel, The 505, Brass Rail Tavern, 505 Tavern, and later Thirsty Duck name usage. **The Wheel is already resolved as a 503-only business; do not search for it as a possible 505 occupant.**

## RL-004 — Harding Building Fire
Oregonian of 2 September 1967 (`E-045`) dates the block fire to 1 September 1967 and names Harding Drug Store and Dixon's Bakery among buildings gutted. Remaining work: fire-department records, insurance, permits, and the replacement-building year. Earlier Enterprise-Courier 1968-1969 search was looking in the wrong years for the fire itself.

## RL-005 — 505 Rear Addition / Building Footprint
Compare assessor sketches, permits, tax cards, Sanborn maps, deeds, parcel maps, and physical measurements to determine whether the rear portion of 505 was added later and whether 505 extends farther back than 503.

## RL-006 — 503 / 505 Width and Boundary Relationship
Research the legal, structural, and practical boundary between 503 and 505 Main. Test the working observation that 503 may be wider while 505 may be deeper.

## RL-007 — Tax Statement and Assessor Record Extraction
Transcribe and cite uploaded tax statements and any assessor/tax materials. Extract parcel descriptions, improvement details, ownership clues, assessed improvement changes, construction dates, and remodel/addition indicators.

## RL-008 — Separate 503 Business / 505 Property Ownership Chains
Document the Young, LaFarlette, Grisham, and Wiitanen relationships to **503 and 505 separately** using deeds, tax statements, assessor records, family records, liquor licenses, business-sale records, and oral history. Treat **Raye LaFarlette and Raye Grisham as the same person** and do not treat the surname change as a Wheel transfer. Test the working family interpretation that the later **Grisham-to-Wiitanen transition was a sale of The Wheel business at 503**. Do **not** use the superseded Mrs. Nemeth/Nesmeth recollection as evidence that the Wiitanens bought the 503 real estate.

For **505 Main**, family history now gives a specific sequence to document: Dick and Sheila **operated Brass Rail first**, then later **purchased the 505 building from Mrs. Nesmeth / Nemeth**. Find the deed, tax-card, assessor, or title record establishing the purchase date, seller's correct name/spelling, and grantees. Then document continuous Wiitanen property ownership through Dick's November 2024 death and the estate transfer to Rodney and Mitch.

## RL-009 — Mitch Young / 505 Tavern License Pages
Locate OLCC, business-registration, directory, and advertisement pages for March 1991-March 2004 to confirm the legal entity name behind the working trade name 505 Tavern.

## RL-011 — 505 Tavern / Brass Rail / Dug Inn Operator and Repossession Sequence
Reconstruct the **505 business-owner/operator chain independently from the 505 real-estate ownership chain**. Start with Ray Hansen's exact period and disposition of the business, then document **Dick and Sheila's original Brass Rail operating period before they owned the building**, including the business-sale and rename dates. Next determine when the Brass Rail operating business was sold away after the Wiitanens became landlords, later defaults/repossessions, the 1988 Dug Inn transfer, Sports Keg and Rosser leads, and the path to Mitch Young's March 1991 purchase.

Use `E-030` as firm evidence of a Wiitanen transfer role on 6 April 1988, but place it in the **later sale/repo/transfer cycle**, not as evidence that their Brass Rail operation began then. Do not use the withdrawn 1981 Troutdale Sandy Post ad.

## RL-010 — 1925 Sanborn 501 / 503 / 505 Question
Review the 1925 Sanborn map and related city directories to determine what was labelled 501, 503, and 505 Main Street, whether 501 was a separate address, and how that relates to the later 503/505 building footprint.

## RL-012 — 503 Modification Around 2017
Confirm the reported significant 503 Main Street modification around 2017 using permits, photos, assessor records, business-opening articles, and owner/tenant records.

## RL-013 — Time Capsule Maps Photo Source Recovery
For Main Street images imported into Time Capsule Maps, recover original source URLs, collection names, photographer names, licensing/citation terms, and exact image dates where possible. Treat current metadata as project metadata until original sources are found.

## RL-014 — 505 Commercial Lease Continuity Record
Use the 2025 lease as a current administrative anchor for 505 Main Street, but do not infer earlier business names from it. Future updates should add amendments, tenant changes, OLCC licenses, permits, and current-business metadata as separate evidence records.

## RL-015 — Oregonian Clipping Transcription and Integration Backlog
Transcribe and evaluate the 10 committed Oregonian clippings `S-049` through `S-058`. For each clipping, record the exact publication date, page/section when visible, headline or classified heading, relevant names/addresses/businesses, and a faithful transcription or summary. Create new `E-###` evidence only for claims actually supported by the clipping, then update the related 503/505 building histories, business/person records, timeline, open questions, research leads, crosswalks, and YAML sidecars as appropriate. Particular attention should be given to whether the 1908 item affects address chronology, the 1937 item clarifies Kwality ownership/operation, the 1960 item establishes Wheel chronology, the September 1967 fire item distinguishes the neighboring 503/505 businesses or building impacts, the 1976 classified clarifies the 505 transition, and the 1983-1985 items clarify The Wheel's later chronology. Do not infer facts from filenames alone; close or split this lead only after all ten sources have been reviewed.

## RL-016 — Mrs. Nesmeth / Nemeth and 505 Deed
Priority property lead. Identify the woman remembered as **Mrs. Nesmeth / Nemeth** and locate the deed by which Dick and Sheila Wiitanen purchased **505 Main Street** from her. Search spelling variants including Nesmeth, Nemeth, Nesmith, and similar forms, but do not merge identities without evidence. Extract grantor/grantee names, deed date, recording date, instrument number, legal description/APN, consideration if available, and whether both Dick and Sheila were grantees.

## RL-017 — Richard Wiitanen Estate / 505 Transfer, 2024-2025
Locate probate, deed, assessor, or estate-transfer records confirming that **505 Main passed to Rodney Young and Mitchell Young as part of Richard / Dick Wiitanen's estate after his November 2024 death**. Determine the exact vesting date, deed/instrument, estate or trust entity involved, and when 505 LLC became the operative ownership/lessor vehicle reflected in the 2025 lease.

## RL-018 — Obtain the 1924 Oregon City Directory
A 1992 National Register nomination (`S-069` / `E-056`) cites **R. L. Polk and Company, Oregon City Directory, 1924** and identifies Oregon City Planning Department as the local repository for additional data. Obtain or inspect the actual directory. Priority target: the Main Street address index for **501, 503, 505, 507 and adjacent numbers**, plus alphabetical/business listings for known occupants.

## RL-019 — Identify the 1925 501 Main Store / Test the Holman Address Mapping
The 1925 Sanborn directly shows **501 Main as a store** (`E-020`), but the tenant is unknown. Primary newspaper evidence places Holman/Randall/Holman undertakers at **Fifth & Main** in 1915–1917 (`E-054`). Determine whether that premises later carried the number **501 Main**, when Holman/Holman & Pace left the corner, and which business occupied 501 by 1924–1925. Do not equate Fifth & Main with 501 without direct address-mapping evidence.

## RL-020 — Recover the Claimed 1914 Holman Move Notice
An earlier working statement said Holman moved into new quarters at Fifth & Main in 1914, but the contemporaneous page supporting that statement has not been recovered. Search 1914 Oregon City newspapers for Holman, Randall, undertaker, new quarters, Fifth/Main, and relocation wording. Until recovered, **do not cite 1914 as the start date**; direct evidence currently begins in June 1915.

## RL-021 — Physical Source Mirroring Backlog
Physically mirror original source binaries where the current web/file-transfer environment could verify but not copy them. Current priority includes newspaper pages `S-064` through `S-068`, NPS source `S-069`, and the previously noted government PDFs `S-062` and `S-063`. Source-capture notes and canonical URLs are already preserved; this lead is specifically about retaining local binary copies.

**20 August 2026 status:** Direct binary downloads were attempted through both the container/file-transfer path and browser-accessible source endpoints. The browser can verify/render these PDFs, but the available transfer path does not expose the remote PDF bytes for repository upload. Keep the canonical URLs and verified source captures; if local binary preservation is required, obtain/upload the original files manually or retry when a binary-capable source path is available.

## RL-022 — Verify the 1925 Municipal Activities Report Fire Claim
Obtain the original **1925 Municipal Activities Report** and verify or refute the earlier conversational claim of an **18 April 1925 fire on Main between 5th and 6th caused by a chimney spark**. The specific entry has not been independently recovered, so it must not be cited as evidence until the original report is inspected. If confirmed, archive the report and assess whether it can be tied to 501, 503, 505, or another storefront.

## RL-023 — Inspect the 1905–1906 Oregon/Washington Business Directory
A catalog/search result identifies an **Oregon and Washington Gazetteer and Business Directory, 1905–1906** as a potentially high-value source for the year-by-year Main Street reconstruction. The underlying directory pages were not accessible during the 20 August 2026 research session because the viewer required sign-in. Inspect the Oregon City listings when access is available, with priority on **501, 503, 505, 507 and adjacent Main Street addresses**, plus businesses documented in the 1904–1906 newspaper evidence. Treat the directory as a source lead only until its pages are actually inspected.

## RL-024 — Watch for 5th–6th Main Construction, Demolition, Fire, and Rebuilding
During every year-by-year research pass, actively search for **new construction, demolition, building removal/moving, fire, major remodeling, excavation, permits, property redevelopment, and street/grade work on Main Street between Fifth and Sixth Streets**, including relative descriptions such as Fifth & Main, Sixth & Main, opposite/near the Post Office, and named neighboring businesses. The objective is to determine when the commercial footprints shown on the **1900 Sanborn** were replaced or materially altered before the later **501 / 503 / 505** pattern and the c.1919/c.1920 dates reported by later historic inventories. Record negative searches as research status, and do not equate a fire or construction event with 501/503/505 unless the location can be mapped independently.

**1912 update:** `E-090` / `S-105` proves that buildings were actively being torn down and replaced **somewhere on Main Street** in May 1912. The source does not identify the Fifth–Sixth block or any numbered target premises. Continue treating 1912 as a confirmed Main Street structural-change year while keeping the exact buildings unresolved under `RL-038`.

## RL-025 — Recover the 1906 Oregon City Street-Numbering Ordinance and Plat
Primary 1906 newspaper evidence (`E-061` / `S-075`) shows that Mayor Caufield approved a street-numbering ordinance and that a **plat designating the correct numbering** of homes and places of business was filed with City Recorder Dimick. Locate the original ordinance, numbering plat/maps, recorder copy, council proceedings, or later archival reproduction. Highest priority is the Main Street frontage of **Block 26 between Fifth and Sixth**, because the plat may directly establish the original 1906 numbers for the storefronts later known as 501, 503, 505, and 507. Search Oregon City Recorder/eVault records, council proceedings, library microfilm, historic planning files, and Clackamas County/Oregon City map collections.

## RL-026 — Reconstruct Block 26 Lot-to-Address Mapping
Use `E-064` as a fixed 1906 anchor: the historic William Tell Hotel at **Sixth & Main** corresponds to **lot 8, Block 26**. Reconstruct all Block 26 lot boundaries and map them to Main Street addresses using the original Oregon City plat, 1900 and 1925 Sanborn maps, the 1906 numbering plat (`RL-025`), deeds/realty transfers, tax/assessment records, and later address evidence. The immediate goal is to determine which Block 26 lots held the predecessor buildings corresponding to later **501 / 503 / 505 / 507 Main** and to narrow the dates when those footprints were rebuilt or replaced.

**1910 update:** `E-078` / `S-092` now replaces the earlier 1910 construction clue with direct primary evidence. On 29 June 1910 Council explicitly authorized contractor J. G. Killgreen to occupy portions of Main and Sixth adjoining the **Gambrinus property at Sixth & Main** for materials for **construction of a new building at that location**; by 26 August the *Courier* reported the basement complete for the new two-story Gambrinus business block. This creates a documented structural-change event on the Gambrinus property after the 1906 William Tell sale. Do not call it the demolition/replacement of the William Tell structure until the demolition/continuity link is directly recovered (`RL-031`).

A later **1913 assessment/tax notice** lists Block 26 ownership by lot: **lot 5 — Mary E. Barlow / Juliette E. David; lot 6 — First National Bank; lot 7 — Frank Jaggar; lot 8 — Gambrinus Brewing Company**. Formally register and analyze that page during the 1913 pass or a dedicated Block 26 reconstruction. It strengthens later ownership continuity but is not treated as 1910 evidence.

## RL-027 — Identify the 1907 Pacific States Telephone Office Address and Lot
`E-065` / `S-079` places the newly completed Pacific States Telephone & Telegraph central office on the **east side of Main between Fifth and Sixth** in spring 1907 but gives no number or lot.

**1910–1911 update:** repeated *Courier* advertisements (`E-082` / `S-095`, `E-088` / `S-101`) directly place **Pacific Telephone & Telegraph Co. at 510 Main Street** from August 1910 into January 1911. The exact late-1910/1911 office address is therefore resolved. Remaining work is narrower: prove whether the 510 Main premises were continuously the same physical central-office plant completed in 1907 and expanded in 1908. Do **not** backdate the 510 number to 1907 without that continuity evidence.

## RL-028 — Identify the May 1908 Fifth–Sixth Shoe Retailer
`E-072` / `S-086` proves that a shoe retailer advertised from **Main Street between Fifth and Sixth Streets** for a 27 May 1908 promotion, but the available OCR/layout does not reliably preserve the merchant name. Inspect the original page image at high resolution, adjacent issues, repeated sale advertisements, directories, and shoe-business notices to identify the merchant and determine whether the premises correspond to 501, 503, 505, 507, or another storefront. Do not identify the retailer from product type or later tenants alone.

## RL-029 — Resolve the Harding Building Footprint and Numbering, c.1909–1912
`E-077` / `S-091` corrects the prior unsupported archive statement that **507 Main was the Harding Building by 1909**. Current primary evidence supports a Harding Building existing around 1909 and places it on **Main Street between Fifth and Sixth** by March 1911, but does not establish its exact number, lot, or footprint.

`E-081` / `S-094` lists **Geo. A. Harding at 611 Main St.** in September 1910. This is Harding's business address and is **not** automatically the Harding Building address.

`E-085` / `S-098` adds two 1911 descriptions that must be reconciled rather than collapsed: a repair-shop item places the **Harding Building on Sixth Street between Main and Railroad Avenue**, while George Young's move notice calls his former premises the **Harding Building on Main Street between Fifth and Sixth** and says he moved **one door north into the Willamette Building**.

**1912 update:** the visually verified 5 January address page (`E-092` / `S-102`) places **G. H. Young at 507 Main** and **Geo. A. Harding's own business at 511 Main**. These facts strengthen the Willamette/Harding mapping problem but still do not establish the Harding Building's exact number. Keep George Harding's business address separate from the named building and continue the dedicated adjacency test under `RL-035`.

## RL-030 — Complete Visual Review of 1909 Courier Pages Not Exposed by the Current Interface
The enhanced 1909 *Oregon City Courier* pass used the annual issue-review protocol and reviewed all retrievable/indexed pages surfaced through the current Historic Oregon Newspapers research interface, while separately running target-address, business-name, construction, fire, demolition, repair, move, and location searches. Some 1909 issue landing pages expose the page/image sequence but their individual page OCR/image endpoints were not retrievable in the current interface. Complete the remaining visual scan through the Oregon Digital/Historic Oregon Newspapers browser, library access, microfilm, or another viewer that exposes every page image. Preserve a checklist of issue date/page coverage. This is a **coverage-completeness follow-up**, not evidence that the inaccessible pages contain or do not contain target-block material.

## RL-031 — Determine the Exact William Tell-to-Gambrinus Building Replacement Sequence
Primary evidence establishes the historic three-story frame **William Tell Hotel at Sixth & Main / lot 8, Block 26** in October 1906 (`E-064`) and a **new Gambrinus building under construction at the Gambrinus property at Sixth & Main** in June–August 1910 (`E-078`). `E-086` / `S-099` shows the **new Gambrinus block occupied by 3 March 1911**, when the Electric Hotel rented its entire second story as an annex. `E-091` / `S-103` now adds a **Gambrinus Saloon at Sixth & Main under William Trudell** in March 1912. Recover the demolition permit/report, contractor/building permit, deed/property description, insurance record, photograph, assessment change, or newspaper item that explicitly connects the old William Tell structure to the 1910 construction. Determine the demolition date and whether any part of the earlier building survived. Also test whether the 1909 Philip Street repair (`E-075`) or Hodes saloon (`E-076`, `E-079`) occupied that same property. Until then, describe the sequence as new construction and later Gambrinus-associated occupancy/use on the property, not as a proven direct demolition replacement.

## RL-032 — Complete Visual Review of 1910 Courier Pages Not Exposed by the Current Interface
The 1910 annual pass reviewed targeted search results and all useful indexed/retrievable *Oregon City Courier* pages surfaced through the current interface, including issue-level browsing and page-specific advertisements/local reports. Some issue/page images are not reliably retrievable through this research interface. Complete the remaining physical-page visual scan through Historic Oregon Newspapers/Oregon Digital, library microfilm, or another viewer and preserve an issue-date/page checklist. This is a coverage-completeness follow-up only; inaccessible pages are not treated as negative evidence.

## RL-033 — Map the Multiple 1910 Sixth/Main Businesses to Specific Corners and Lots
`E-081` / `S-094` places **Price Bros.** at Sixth & Main in March and September 1910 and **Watson B. Eddy & Son** at Main & Sixth in September. `E-078` independently documents the new Gambrinus block at the intersection, while `E-079` documents Hodes having vacated a Sixth/Main saloon earlier that year. Determine which corner/lot each business occupied using directories, deeds/leases, advertisements with neighboring-business language, photographs, building permits, and the 1906 numbering plat. Do not assume multiple businesses described at the same intersection occupied the same building.

## RL-034 — Complete Visual Review of 1911 Courier Pages Not Exposed by the Current Interface
The 1911 annual pass combined exact-address/business/construction searches with issue/page review of retrievable/indexed *Oregon City Courier* pages. The page-level pass materially helped recover the Chicago Store 405→505 move window, the Harding/Willamette location wording, the Gambrinus occupancy item, and Sixth Street grade work. Some 1911 issue/page images are not reliably exposed through the current research interface. Complete the remaining physical image-by-image scan through Historic Oregon Newspapers/Oregon Digital, library microfilm, or another full-page viewer and preserve an issue-date/page checklist. Inaccessible pages are not counted as visually reviewed and are not negative evidence.

## RL-035 — Test Harding / Willamette Building Adjacency Against 505 / 507 Numbering
`E-085` / `S-098` establishes that on 10 March 1911 George Young moved **one door north** from his former Harding Building premises on Main between Fifth and Sixth into the Willamette Building. `E-084` shows The Chicago Store entering **505 Main by 31 March 1911**. The 1912 pass now directly registers the visually verified **G. H. Young — 507 Main** listing from 5 January 1912 as `E-092` / `S-102`.

This creates a plausible geometric hypothesis that the Willamette Building may have corresponded to 507 Main and the immediately south Harding premises to a neighboring address such as 505. The evidence still does **not** prove that Young remained continuously in the same Willamette premises from March 1911 through January 1912, nor that the named Harding Building was 505. Recover a 1911–1912 advertisement, directory, deed/lease, photograph, Sanborn annotation, or other direct source naming the Willamette and/or Harding Building with an exact number before making the assignment.

## RL-036 — Complete Visual Review of 1912 Courier Pages Not Exposed by the Current Interface
The 1912 annual pass combined exact-address/business/construction searches with issue/page review of retrievable/indexed *Oregon City Courier* pages. The page-level pass materially helped recover the visually verified January **503 / 507 / 509 / 511** address ladder and the May present-tense Main Street demolition/rebuilding statement. Some 1912 issue/page images are not reliably exposed through the current research interface. Complete the remaining physical image-by-image scan through Historic Oregon Newspapers/Oregon Digital, library microfilm, or another full-page viewer and preserve an issue-date/page checklist. Inaccessible pages are not counted as visually reviewed and are not negative evidence.

## RL-037 — Resolve H. N. Smith vs H. H. Smith at 503 Main, 1912
`E-089` documents **H. N. Smith** advertising a pool room at **503 Main** on 5 January, while March and July sources identify **H. H. Smith** with a 503 Main / Fifth-and-Main pool hall. The close chronology, business type and location strongly suggest a connection and possibly the same operator, but the initials conflict must be resolved rather than normalized away. Search directories, pool-hall licenses, Council minutes, advertisements, census/vital records, and Aurora business notices for the full name and identity. Also determine whether the July Fifth/Main description can be independently mapped to the exact 503 storefront footprint.

## RL-038 — Identify the Main Street Buildings Torn Down / Replaced in 1912
`E-090` / `S-105` proves that Oregon City was actively **tearing down buildings on Main Street and building new ones in their places** in May 1912, but the editorial supplies no block, owner, business or address. Identify the projects through adjacent *Courier* and *Morning Enterprise* issues, building permits, Council records, contractor notices, realty transfers, tax/assessment changes, photographs, and later historic inventories. Highest priority is testing whether any project involved **Block 26 between Fifth and Sixth** or predecessor premises at 501/503/505/507. Until a direct mapping source is recovered, do not attribute the May teardown statement to the target buildings.