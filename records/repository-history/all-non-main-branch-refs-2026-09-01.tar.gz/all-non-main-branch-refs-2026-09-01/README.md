# Recovered non-main branch-ref archive

This archive was rebuilt from the branch tip IDs preserved in the repository's 2026-09-01 manifest after the original tarball was found missing. Each branch directory contains metadata, a branch-only commit log, a binary Git diff, and the tip version of every path changed from its merge base.
