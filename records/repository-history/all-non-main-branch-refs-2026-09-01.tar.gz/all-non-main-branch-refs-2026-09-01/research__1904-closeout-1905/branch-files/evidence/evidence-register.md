# Evidence Register

## E-001 — White Rabbit Black Ink Article
Type: Secondary source  
Date: 2017  
Claims: 503 Main constructed in 1919; originally housed Kwality Cafe; article later calls the business "The Wheel Tavern." The phrase **"The Wheel Tavern" is preserved as source wording only** and is superseded as a business-name claim by the August 2026 family correction: it was never an official name.  
Confidence: Moderate for 1919; strong for Kwality connection; **not accepted as evidence of an official "The Wheel Tavern" name**.  

## E-002 — New Kwality Cafe Matchbook
Type: Primary artifact  
Claims: New Kwality Cafe at 503 Main St.; J. Jager, Prop.; 'We Never Close.'  
Related media: `IMG-0001`  
Confidence: Very High.

## E-003 — Larry's Kwality Cafe Matchbook
Type: Primary artifact  
Claims: Larry's Kwality Cafe at 503 Main Street; telephone 6106; merchant lunches, steaks, chops.  
Related media: `IMG-0002`  
Confidence: Very High.

## E-004 — Mitch Young Direct Testimony
Type: Primary participant testimony  
Date: Confirmed March 1991-March 2004; family context updated August 2026  
Claims: Mitch Young / Mitchell Young / Mitch C. Young / Mitchell C. Young are the same person (`P-011` / `P-018`). He **ran** (owned and operated) **505 Tavern** at 505 Main Street from March 1991 to March 2004. Family history adds that he purchased the tavern business after a repossession. Earlier wording that he **restored** the 505 Tavern name or anything else is superseded: it is not known whether he restored a name, fixtures, or the building. This period is not The Wheel.  
Confidence: Very High for ownership/operation dates and 505 Main location; high as working trade name **505 Tavern** pending license/directory pages.

## E-005 — Ray Hansen / 505 Tavern Earlier Ownership Account
Type: Family/oral history  
Claims: Family history identifies **Ray Hansen** as an owner/operator in the earlier 505 Tavern business chain and places a later transition to Dick and Sheila Wiitanen, who operated the business as **Brass Rail**. He is a different person from Raye Grisham. Historical Society v5 used "Hanson" as a search variant; current family confirmation keeps **Hansen**. Exact Hansen-to-Wiitanen sale date, legal entity, and rename date remain pending primary records.  
Confidence: High for Hansen identity, separate 505 association, and family-reported sequence; exact transaction mechanics/date require primary records.

## E-006 — Willie Bartender
Type: Family/oral history  
Claims: Willie worked as bartender under Ray Hansen and continued into a later 505 transition period associated in family memory with Richard / Dick and Sheila. Exact dates and legal employer remain open.  
Confidence: High for remembered continuity, pending full identification and operator chronology.

## E-007 — Victor Restaurant Manager
Type: Family/oral history  
Claims: Victor independently managed the restaurant during **Raye Grisham's Wheel years at 503 Main** and the early **Wiitanen Wheel period at 503**. This is 503 history and should not be used to infer operation of the 505 tavern.  
Confidence: High, pending full identification.

## E-008 — 2017 505 Tavern / Thirsty Duck Article
Type: Secondary source  
Claims: Mike Berman sold the business; Scott Forvilly purchased it; it reopened as Thirsty Duck in 2017.  
Confidence: Strong for 2017 transition.

## E-009 — Young / LaFarlette / Grisham / Wiitanen Family Context
Type: Family/oral history / project provenance  
Claims: After Richard Wiitanen's death in November 2024, **505 Main passed to Rodney Young and Mitchell Young as part of his estate**; current ownership/stewardship is through 505 LLC. Rodney's grandmother is **Raye Grisham** (first marriage LaFarlette). Rodney's mother Sheila and stepfather Richard / Dick were Wiitanens. Earlier wording that Rodney alone currently owns 505 is superseded by the joint-ownership correction.  
Confidence: High as trusted internal family/project provenance; deed/probate still desirable.

## E-010 — 505 Rear Addition Recollection
Type: Family/oral history  
Claims: Mitch Young recalled or reported that the rear portion of the 505 building may have been added later.  
Confidence: Moderate to High as oral history; needs confirmation through permits, assessor sketches, Sanborn maps, tax records, or physical building analysis.

## E-011 — 503 / 505 Footprint and Width Uncertainty
Type: Owner observation / working research note  
Claims: 505 may extend farther back than 503, while 503 may be somewhat wider. The exact legal, physical, and historical boundary between the two buildings is unresolved.  
Confidence: Moderate as field/owner observation; needs confirmation through tax maps, assessor sketches, deeds, Sanborn maps, and measurements.

## E-012 — Tax Statement / Tax Record Materials
Type: Primary or administrative record, pending transcription  
Claims: Tax statements and related tax record materials may help establish parcel descriptions, assessed improvements, building footprint, construction dates, remodel/addition clues, and ownership history for 503 and 505 Main Street.  
Confidence: Pending extraction/transcription; should be linked to specific uploaded images or documents when added to the archive.

## E-013 — Thebeerchaser 505 Tavern Comment Screenshot
Type: Web screenshot / public comment evidence  
Date: 2021 comment screenshot; comment references 1971 memory  
Claims: A commenter recalled the 505 Tavern on Main St. in connection with Publishers Paper workers and a 1971 draft-number celebration; Thebeerchaser replied with a memory of delivering the paper to the 505 and being greeted by the bartender while regulars, including Publishers workers, clapped.  
Related media: `IMG-0003`  
Confidence: Moderate for local memory and culture; weak to moderate for formal business chronology until corroborated by directories, business licenses, OLCC records, newspapers, or tax records.

## E-014 — 505 Location Correction / 505 Tavern Handling Note
Type: Project correction / direct user clarification  
Claims: Mitch Young's March 1991-March 2004 period belongs to **505 Tavern at 505 Main Street**, not The Wheel. `BUS-009` The 505 remains as an earlier handling label. **The Wheel was only at 503 Main.**  
Confidence: High for archive-handling rule; license/directory pages still desirable for the legal entity name.

## E-015 — Time Capsule Maps Photo Metadata: 503 / 505 / 5th-Main
Type: Project metadata / photo metadata export  
Claims: One photo metadata record labels The Wheel at 503 Main Street and notes 505 Tavern to the right at 505 Main Street. Another circa-1910 5th/Main record says the first building in the picture is gone and is now 503 and 505 Main; the 1925 Sanborn shows 501, 503, and 505; the 501 history is unclear; 503 was significantly modified around 2017.  
Related media: `IMG-0004`, `IMG-0005`  
Confidence: High as trusted internal project metadata for what Time Capsule Maps records; original image/source details should still be cited when making external historical claims.

## E-016 — Harding Building Fire Oral / Project Notes
Type: Family/oral history / project note  
Claims: The Harding Building at 507 Main burned in the late 1960s, likely late 1968 or 1969. Tony's Restaurant and a bakery were involved, and the fire may have started in or spread through the bakery area. **Date and origin superseded by `E-045`** (Oregonian: fire 1 September 1967; reported origin Howard Cohn warehouse). Keep this item as the earlier notes.  
Confidence: Moderate to High as project/oral-history evidence; requires newspaper, fire department, permit, assessor, or city-record confirmation.

## E-017 — Photo Metadata: Harding Building Replacement Note
Type: Project metadata / photo metadata export  
Claims: The circa-1910 5th/Main photo metadata notes that the taller Harding Building at 507 burned and was replaced by the current building.  
Related media: `IMG-0005`  
Confidence: High as trusted internal project metadata for what Time Capsule Maps records; original image/source details should still be cited when making external historical claims.

## E-018 — 505 Commercial Lease, 2025
Type: Current administrative/legal record  
Claims: 505 LLC leased 505 Main Street, Oregon City, to Alin Guria for a primary term from July 1, 2025 through June 30, 2030; base rent $2,700/month; use is Restaurant/Bar; lease includes NNN-style additional rent, taxes/assessments, utilities, insurance, liquor liability, OLCC/permit obligations, and Skyline Property Management as property manager/authorized agent.  
Related record: `records/505-commercial-lease-2025.md`  
Confidence: Very High for current lease facts shown in the lease document; not evidence for earlier business names.

## E-019 — Family Name / Death-Date Correction
Type: Project correction / direct user clarification  
Claims: Grandmother's first marriage was Lafarlette and second marriage was Grisham. Rodney's mother Sheila and stepfather Richard / Dick were Wiitanens. Richard / Dick died in November 2024; Sheila died in 2014.  
Confidence: High as trusted internal family/project correction; formal records may later add full dates and spellings.

## E-020 / EV-SAN-1925-1950-001 — Sanborn Map Series: 5th / Main / 503-505-507 Context
Type: Primary map evidence  
Sources: `S-014` through `S-022`; detailed comparison file: `maps/sanborn-comparison-503-505-507.md`; structured note: `evidence/sanborn-1925-1950-evidence.md`  
Claims: The Sanborn series shows a developed Main/5th commercial frontage before the later-reported 1919 construction date. The 1925 sheet labels separate Main Street addresses including 501, 503, 505, and 507; 501 appears as a store, 503 as restaurant, 505 as billiards/cigars, and nearby spaces include dry goods/clothing, grocery, drugs, and I.O.O.F. Hall. The 1950 revised sheet continues to show separate 503/505/507 occupancies, with 503 restaurant and 505 billiards/cigars/beer-related use.  
Confidence: High for the map-visible address/occupancy pattern on the 1925 and 1950 sheets; exact abbreviation readings and earlier 1884-1900 address-to-modern-address mapping require careful transcription.

## E-021 — Aerial Photocompare Series: 5th & Main / McLoughlin Context
Type: Aerial photograph evidence (viewer screenshots)  
Sources: `S-023`; detailed analysis: `evidence/aerial-5th-main-photocompare-series.md`  
Related media: `IMG-0006` through `IMG-0043`; key frames: `IMG-0007` (1936), `IMG-0009` (1944)  
Claims: Oregon City photocompare aerial series (1929–2025) centered on 5th & Main shows McLoughlin Blvd / US99E labeling by 1929 and a wider graded highway corridor west of Main by 1936. The 1936 frame shows three distinct roofs at 501, 503, and 505 Main. By 1944 the 501 Main footprint is absent, and the east-side building across from 500 Main (Sanborn-labelled counterpart) is also no longer present — establishing **501 Main removal between 1936 and 1944**. Remaining Main-frontage structures north of the former 501 corner persist through mid-century. 1996 flood frame shows high water near riverfront / McLoughlin corridor.  
Confidence: Moderate to high for 501 existence in 1936 and removal by 1944; moderate for highway/corridor labeling; not sufficient alone for business names, ownership, or legal cause of demolition.

## E-022 — August 2026 Family Identity, Address, Business-Separation, and 505 Property Corrections
Type: Direct user / family confirmation  
Date: 16–19 August 2026  
Claims: **Raye LaFarlette and Raye Grisham are the same woman**; the surname change followed divorce/remarriage and is not evidence of a Wheel business transfer. Raye bought **The Wheel at 503 Main**. **The Wheel was only at 503 Main and was never a 505 Main business. "The Wheel Tavern" was never an official name**; that phrase survives only as wording in the 2017 secondary article (`E-001`). Ray Hansen is a different person associated with the separate 505 Tavern history. **The 503 Wheel business and 505 tavern business had separate ownership/operator chains.** At 505, **Dick and Sheila Wiitanen ran Brass Rail for a period before they owned the building**. They later bought the **505 Main real estate** from a woman remembered as Mrs. **Nesmeth / Nemeth** (spelling uncertain). After that purchase, Wiitanen ownership of the 505 real estate continued through Richard / Dick Wiitanen's death in **November 2024**; Sheila had died in 2014. The building then passed to **Rodney Young and Mitchell Young as part of Dick's estate**. After Dick and Sheila became 505 landlords, later appearances of a Wiitanen in 505 business-transfer records may represent sale, repossession, non-payment/default, or transfer intervals rather than continuous tavern operation. Working family interpretation is that the later **Raye Grisham → Wiitanen transition at The Wheel was a sale of the 503 business**, not proof of a 503 real-estate purchase; exact date, terms, and license documents remain pending. Mitch / Mitchell (C.) Young ran 505 Tavern 1991-2004; do not say he restored it. Mitch Young and Mitchell C. Young are the same person.  
Confidence: High as current family confirmation for identity, address, naming, Brass Rail/business-property sequence, and estate succession; documentary deeds/licenses/probate still desirable for exact dates and legal mechanics.

## E-023 — H. H. Smith Pool-Hall Application, 503 Main, 1912
Type: Primary newspaper legal notice  
Sources: `S-024`  
Claims: March 1912 Morning Enterprise notice that H. H. Smith intended to apply for a license to run a pool hall at his place of business, 503 Main Street. Does not by itself prove the license was granted.  
Confidence: Very High for the application and address; unresolved for grant.

## E-024 — L. Hylton at 503 Main, 1914
Type: Primary newspaper profile  
Sources: `S-025`  
Claims: 12 February 1914 Oregon City Courier industrial edition profiles L. Hylton at 503 Main as a dealer in cigars, tobacco, smokers' supplies, and soft drinks.  
Confidence: Very High.

## E-025 — The Wheel at 503 Main, Oregon City Commission, 7 June 1967
Type: Primary municipal record  
Sources: `S-027`  
Claims: Commission minutes authorize the mayor to sign a liquor application for "the Wheel located at 503 Main Street."  
Confidence: Very High for address and name as of that date.

## E-026 — The Chicago Store at 505 Main, 1911-1913
Type: Primary newspaper advertisements  
Sources: `S-032`  
Claims: Oregon City Courier ads 14 and 28 April 1911 and Morning Enterprise 8 January 1913 place The Chicago Store at 505 Main (new/second-hand clothing, cleaning and repairing).  
Confidence: Very High.

## E-027 — Wolf & Miller at 505 Main, 1918
Type: Primary newspaper feature  
Sources: `S-034`  
Claims: 10 October 1918 Oregon City Courier identifies Wolf & Miller, 505 Main, in a shoe business / modern shoe-repair department discussion. Shows the 505 address occupied in 1918; not proof the surviving building already existed.  
Confidence: Very High for occupant/address.

## E-028 — Dr. Freeze, Eye Specialist, 505 / 505 1/2 Main, 1921-1922
Type: Primary newspaper advertisements  
Sources: `S-035`  
Claims: Dr. Freeze advertised as Eye Specialist at 505 or 505 1/2 Main, opposite the post office, 1921-1922 (exams, glasses, lens grinding). By October 1922 he advertised from rooms 207-8, Masonic Building. Preserve historical title "Eye Specialist."  
Confidence: Very High.

## E-029 — 505 Tavern Liquor Renewals, 1965 and 1972
Type: Primary municipal records  
Sources: `S-038`, `S-039`  
Claims: Oregon City Commission liquor-license renewals list 505 Tavern in November 1965 and March 1972.  
Confidence: Very High.

## E-030 — The Dug Inn Formerly Brass Rail, 1988
Type: Primary municipal record  
Sources: `S-041`  
Claims: 6 April 1988 Commission Manager's Report No. 88-49 identifies The Dug Inn (formerly The Brass Rail) at 505 Main Street and a change-of-ownership application from Dick or Sheila Wiitanen to the Cotterells. This is strong evidence that a Wiitanen was acting as business transferor at that moment. Because family history now establishes an earlier Dick/Sheila Brass Rail operating period **before** their later purchase of the 505 building, the 1988 transfer must be placed within the later sale/repo/transfer cycle rather than used to define the start of their 505 involvement.  
Confidence: Very High for the municipal record and transfer role; exact path into the 1988 transfer remains open.

## E-031 — Hansen-to-Wiitanen / Brass Rail Family Account
Type: Family/oral history, refined by later clarification  
Sources: `S-028`  
Claims: Family history places **Ray Hansen** before Dick and Sheila Wiitanen in the 505 Tavern business chain and says Dick and Sheila later operated the business as **Brass Rail Tavern**. The 19 August 2026 clarification (`E-022`, `E-038`) adds the crucial property sequence: **Dick and Sheila ran Brass Rail before they owned the 505 building**, then later purchased that building from Mrs. Nesmeth / Nemeth. After becoming landlords, the tavern business later passed through other owners/operators; later Wiitanen business-control periods may have involved repossession/default/transfer. `E-030` independently proves a Wiitanen-to-Cotterell change-of-ownership application in 1988. Exact sale/rename/property-purchase dates remain to be reconstructed from business-sale, license, deed, and repossession records.  
Confidence: High as family chronology framework; exact dates and legal mechanics pending primary records.

## E-032 — Oregon City Historic Inventories for 503 and 505 (Official Secondary)
Type: Official secondary synthesis  
Sources: `S-026`, `S-033`  
Claims: City 503 record reports c.1919 construction estimate, Kwality Restaurant 1926, Kwality Cafe 1947, Flor 1957, Wolf-family ownership roughly 1922-1972. City 505 record reports no 1916 directory listing (not proof of vacancy), c.1920/1925 construction estimate, 1941 Dr. Roy Briggs at 505 1/2, 1945 "Harr's Recreation Center," 1953 "Well's Recreation." Original directory pages still needed.  
Confidence: Medium-high as official synthesis; underlying pages preferable.

## E-033 — Farr's Pool Hall Proprietors
Type: Official secondary  
Sources: `S-036`  
Claims: City historic inventory for 401 3rd Street identifies Edwin F. and Alice Farr as proprietors of Farr's Pool Hall at 505 Main. Residence acquired 1934; pool-hall span not fully dated.  
Confidence: High as official independent corroboration.

## E-034 — Michael Berman Bought 505 Tavern in 2009
Type: Primary municipal record / participant statement  
Sources: `S-042`  
Claims: 5 September 2012 Commission minutes record Michael Berman stating he bought the 505 Tavern in 2009.  
Confidence: High.

## E-035 — 2017 505 Permit; Richard Wiitanen Listed as Owner
Type: Primary municipal permit log  
Sources: `S-043`  
Claims: Permit BB-17-0193, issued 18 April 2017, 505 Main / 505 Tavern, lists WIITANEN RICHARD MARTIN CO-TRU as owner and APN 2-2E-31AB-08300. Supports continuing **real-estate** ownership after the earlier Wiitanen purchase of 505 from Mrs. Nesmeth / Nemeth; it is not evidence that Richard was operating the tavern in 2017.  
Confidence: Very High for 2017 permit-era real-estate facts.

## E-036 — Withdrawn 1981 Sandy Post Brass Rail Citation
Type: Research correction  
Sources: `S-040`  
Claims: 1981 Sandy Post Brass Rail Tavern classifieds identify Troutdale at 108 E. Columbia, not Oregon City. Must not be cited as 505 Main evidence.  
Confidence: High as a negative/correction finding.

## E-037 — Bagent / Heath Bark-Ley 2003-2005 Transition Lead
Type: Secondary business records plus participant statement  
Sources: `S-045`, `S-046`, `S-047`  
Claims: Aggregators associate Kenly C. Bagent with Heath Bark-Ley LLC at 505 Main from December 2003 and 505 Tavern registration from March 2004; D&B names Terry Bee Enstad; 3 February 2005 alumni entry has Ken Bagent stating he and partner "Terry Bee" owned two taverns in Oregon City. State filings still needed.  
Confidence: Moderate as leads; not a complete ownership chain.

## E-038 — Corrected Wiitanen Purchase of 505 Building from Mrs. Nesmeth / Nemeth
Type: Family/oral history / project correction  
Sources: `S-028`  
Claims: **The earlier archive claim that Dick and Sheila Wiitanen purchased the 503 Main building from Mrs. Nemeth is superseded.** Current family clarification says Dick and Sheila **first ran Brass Rail at 505 Main while they did not own the building**, then later purchased the **505 Main building** from a woman remembered as **Mrs. Nesmeth / Nemeth** (spelling uncertain). After that purchase, Wiitanen ownership of the 505 real estate continued through Richard / Dick Wiitanen's death in **November 2024**; Sheila died in 2014. The building then passed to **Rodney Young and Mitchell Young as part of Dick's estate**. Exact property-purchase date, seller spelling, deed, and probate/estate transfer documents remain pending.  
Confidence: High as direct family correction for address, sequence, and estate succession; exact legal dates/spelling require primary records.

## E-039 — 1955 Beer-and-Pool Tavern Classified, 505 Main
Type: Primary newspaper classified  
Sources: `S-037`  
Claims: 20 November 1955 Eugene Register-Guard offered a long-established beer-and-pool tavern for sale, inquiries to 505 Main Street, Oregon City. No trade name or owner in the ad.  
Confidence: Very High for a beer/pool tavern at the address in 1955.

## E-040 — Historical Society Edition v5 Working Narrative
Type: Project synthesis / working history  
Sources: `S-048`  
Claims: Consolidates newspaper, municipal, Sanborn, aerial, family, and archive evidence for 503 and 505 as of **16 August 2026**. It predates the later 19 August corrections in `E-022` and `E-038`. Where v5 places the Mrs. Nemeth purchase at 503, implies a different Wiitanen 505 business/property sequence, or treats "The Wheel Tavern" as a possible formal name, the later corrections control. Not a substitute for the underlying primary sources.  
Confidence: High as a dated project synthesis; each claim still rests on its numbered source and later corrections.

## E-041 — Sports Keg / Rosser Family Leads
Type: Family recollection / research lead  
Sources: `S-028`  
Claims: Family recollection places Sports Keg at 505 Main in the late 1980s or early 1990s during changing operators/repossessions. A separate recollection suggests a Brass Rail sale may have involved someone surnamed Rosser (spelling uncertain). No documentary corroboration located in the v5 notes.  
Confidence: Low-moderate as leads only.

## E-042 — Henry Brightbill Store at 503 Main, 1908
Type: Primary newspaper  
Date: 25 August 1908  
Sources: `S-049`  
Related media: `IMG-0044`  
Claims: Oregonian article "Pretty Girl Is Missing" identifies Henry Brightbill as an Oregon City merchant with a store at **503 Main Street**. Occupancy of the address in 1908; not proof that the surviving building dates to 1908.  
Confidence: Very High for the newspaper's address claim.

## E-043 — Kwality Cafe for Sale, Oregon City, 1937
Type: Primary newspaper classified  
Date: 12 June 1937  
Sources: `S-050`  
Related media: `IMG-0045`  
Claims: Oregonian classified: "KWALITY cafe for sale, Oregon City. Manager retiring. Modern." Street number is not in the visible ad; archive association with 503 Main is by other Kwality evidence, not by this clipping alone.  
Confidence: Very High for a Kwality Cafe for sale in Oregon City in 1937; address inference separate.

## E-044 — Wheel Cafe at 5th and Main, 1960
Type: Primary newspaper  
Date: 30 November 1960  
Sources: `S-051`  
Related media: `IMG-0046`  
Claims: Oregonian crime report places "the Wheel Cafe, 5th and Main Streets in Oregon City" as operating in late November 1960. Trade-name form is **Wheel Cafe**. Street number not stated.  
Confidence: Very High for name, intersection, and date.

## E-045 — Main Street Fire, 1–2 September 1967
Type: Primary newspaper  
Date: 2 September 1967 (reports Friday-night fire; 2 September 1967 was Saturday, so the fire was the night of **1 September 1967**)  
Sources: `S-052`  
Related media: `IMG-0047`  
Claims: Oregonian, Jack Berry, "In Oregon City Fire": fire on Main Street between 5th and 6th. Businesses gutted include Coast Hardware Co., Dixon's Bakery, Hardings Drug Store, Volunteers of America Thrift Shop, and a two-story furniture warehouse owned by Howard Cohn (reported origin). **"The only establishments spared by flames in the block were the Wheel Restaurant and the 505 Tavern, both of which received smoke and water damage."** This is primary evidence that **The Wheel/Wheel Restaurant and 505 Tavern were distinct establishments** on the block in September 1967, and that Harding Drug Store was among the buildings destroyed. Origin is reported as the Cohn warehouse, not a bakery. Earlier working dates of late 1968/1969 (`E-016`) are superseded for the fire **date**; keep `E-016` as the earlier notes.  
Confidence: Very High for newspaper date, named businesses, and their distinct existence.

## E-046 — 505 Tavern Classified, 1976
Type: Primary newspaper classified  
Date: 8 February 1976  
Sources: `S-053`  
Related media: `IMG-0048`  
Claims: Oregonian classified offers a Brunswick pool table for sale at **505 Tavern, Oregon City**, phone **655-4321**. Documents the 505 Tavern trade name in 1976.  
Confidence: Very High.

## E-047 — Wheel Cafe as 1983 Community Landmark
Type: Primary newspaper  
Date: 18 April 1983  
Sources: `S-054`, `S-058`  
Related media: `IMG-0049`, `IMG-0050`  
Claims: Oregonian feature by John Guernsey on Sid and Earl Cruzan. They walked daily from Molalla Avenue to downtown Oregon City to lunch at **the Wheel Cafe**. Photo caption treats the Wheel Cafe as a known local destination. Street number not in the visible text.  
Confidence: Very High for name, city, and 1983 operation.

## E-048 — Wheel Cafe, 503 Main St., Lottery Outlet, 1985
Type: Primary newspaper directory listing  
Date: 25 April 1985  
Sources: `S-055`  
Related media: `IMG-0051`  
Claims: Oregonian Clackamas lottery-ticket outlet list includes **"The Wheel Cafe, 503 Main St."**  
Confidence: Very High for name and address on that date.

## E-049 — Richard M. Wiitanen Owner of The Wheel Cafe, 503 Main, August 1985
Type: Primary newspaper  
Date: 21 August 1985 and 27 August 1985  
Sources: `S-056`, `S-057`  
Related media: `IMG-0052`, `IMG-0053`  
Claims: Oregonian identifies **Richard M. Wiitanen** as owner of **The Wheel Cafe** at **503 Main St.**, Oregon City, in August 1985, in connection with Oregon Lottery ticket sales. This is 503 business ownership, not proof of 503 real-estate ownership, not 505 Tavern, and not Mitch Young's later 505 period. Combined with `E-022`, it supports the working hypothesis that the Grisham-to-Wiitanen Wheel transition was a business sale, but it does not establish the transaction date or terms.  
Confidence: Very High for owner name, business name, address, and month; transfer mechanics remain open.

## E-050 — H. P. Brightbill at 509 Main, 5 January 1912
Type: Primary newspaper advertisement  
Date: 5 January 1912  
Sources: `S-059`  
Claims: User-supplied image from the *Oregon City Courier* shows an H. P. Brightbill tea advertisement explicitly giving **509 Main St.**, phone 74, Oregon City. This establishes Brightbill at 509 Main on that date. It supersedes any OCR/transcription reading of 609 Main for this advertisement. Separate 1908 evidence (`E-042`) places Henry Brightbill's store at 503 Main, so movement/address chronology should be researched rather than assumed.  
Confidence: Very High for 509 Main on 5 January 1912.

## E-051 — 1912 Post Office Business Cluster
Type: Primary newspaper advertising / geographic reconstruction  
Date: circa 1912  
Sources: `S-060`  
Related note: `evidence/1912-main-street-postoffice-cluster.md`  
Claims: Contemporary advertisements place **I. Tolpolar opposite the Oregon City Post Office**, **M. E. Dunn near/next door to the P.O.**, **Schrader's Bakery near the Post Office**, and **Pioneer Transfer Co. in the Postoffice Building**. Later evidence places Tolpolar at **514 Main**, providing a strong anchor for the Post Office on the opposite, odd-numbered side. The exact numbered address of the Post Office remains unproven in the current archive. **513 Main is a working candidate only.** If 513 is confirmed as the P.O., Dunn's next-door description combined with Harding at 511 would make 515 a plausible Dunn address; that is inference, not evidence. Schrader must not be assigned to 503/505 or any exact number without direct evidence.  
Confidence: High for relative-location descriptions; Moderate for 513 Post Office hypothesis; Low-moderate for 515 Dunn until directly documented.

## E-052 — Oregon City Courier, 5 January 1912, Page 6 Business Advertisements
Type: Primary newspaper advertising  
Date: 5 January 1912  
Sources: `S-061`  
Related record: `evidence/E-052-1912-page-6-business-ads.md`  
Claims: Page 6 directly places **Bailey & Price, Billiard and Pool Parlors, at 527 Main Street opposite the Grand Theater**; places **Clems Chop House at 5th and Main Street**; and places **Wm. Gardner, Watchmaker and Jeweler, on Main near 8th**. The Chicago Store advertisement says **"Main St. just below Postoffice"**; independent evidence (`E-026`) places the Chicago Store at 505 Main. The same issue also documents H. P. Brightbill at 509 Main (`E-050`).  
Confidence: Very High for the printed advertisement text and explicit 527 Main address; relative-location wording is not converted into exact addresses without independent evidence.

## E-053 — 527 Main / Swartz Building, 1935
Type: Official historic-resource survey evidence / secondary source  
Sources: `S-062`, `S-063`  
Related record: `evidence/E-053-527-main-swartz-building-1935.md`  
Claims: Official City of Oregon City and ODOT historic-resource sources identify the **present 527 Main building as the Swartz Building and date it to 1935**. Because `E-052` directly places Bailey & Price at 527 Main in 1912, the 1912 business occupied a predecessor building/storefront at that number unless a later renumbering is demonstrated. The City report also notes later entrance alteration.  
Confidence: High for the accepted historic-inventory identification and 1935 date; Very High that the 1912 numbered-address evidence predates the present 1935 building, assuming no intervening address renumbering.

## E-054 — Holman / Randall Undertaking Business at Fifth & Main, 1915–1917
Type: Primary newspaper advertisements  
Sources: `S-064`, `S-065`, `S-066`  
Related record: `evidence/E-054-holman-fifth-main-1915-1917.md`  
Claims: Newspaper advertisements place **R. L. Holman and T. P. Randall at Fifth and Main** in June 1915 and March 1916, and **R. L. Holman at Fifth and Main** in January 1917. The ads do **not** print 501 Main. Because the 1925 Sanborn later shows 501 as the corner store space, equivalence with 501 is a research hypothesis only.  
Confidence: Very High for Fifth-and-Main location and dates; Moderate hypothesis only for equivalence with later-numbered 501 Main.

## E-055 — Holman & Pace Business Continuity, 1918–1921
Type: Primary newspaper references / advertisements  
Sources: `S-067`, `S-068`  
Related record: `evidence/E-055-holman-pace-1918-1921.md`  
Claims: 1918 newspaper references identify a **Holman & Pace chapel / funeral parlors**, and a 17 February 1921 advertisement identifies **Holman & Pace** as undertakers, embalmers and funeral directors in Oregon City. The recovered sources do **not** state Fifth & Main or 501 Main, so they cannot prove continued occupancy of the earlier corner premises.  
Confidence: High for business continuity; Unresolved for location after the January 1917 Fifth-and-Main advertisement.

## E-056 — 1924 Oregon City Directory Existence / Repository Lead
Type: Official National Register documentation citing a historical directory  
Sources: `S-069`  
Related record: `evidence/E-056-1924-oregon-city-directory-source-lead.md`  
Claims: A 1992 National Register nomination cites **R. L. Polk and Company, Oregon City Directory, 1924** and identifies the Oregon City Planning Department as a local repository for additional data. The nomination does **not** reproduce Main Street directory entries and therefore is not evidence for a specific occupant.  
Confidence: Very High for existence/citation of the 1924 directory and repository lead; None yet for 501/503/505/507 occupants from that directory.

## E-057 — I. Tolpolar on Main Street, 1904
Type: Primary newspaper advertisements  
Date: October–December 1904  
Sources: `S-070`  
Related record: `evidence/E-057-1904-tolpolar-main-street.md`  
Claims: *Oregon City Enterprise* advertisements on 21 October, 4 November, and 30 December 1904 place **I. Tolpolar** and his furniture/household-goods business on **Main Street, Oregon City**. The ads do not give a numbered address. The repository already contains `newspapers/oregon-city-enterprise/1904-tolpolar-main-street-ad.pdf`; its exact issue/page still needs reconciliation before attaching a specific publication date to that binary.  
Confidence: Very High for Tolpolar operating on Main Street in late 1904; Unresolved for the exact numbered address or a connection to modern 503, 505, or 507 Main.

## E-058 — I. Tolpolar on Main Street, 1905
Type: Primary newspaper advertisement  
Date: 3 February 1905  
Sources: `S-071`  
Related record: `evidence/E-058-1905-tolpolar-main-street.md`  
Claims: The 3 February 1905 *Oregon City Enterprise* advertises **I. Tolpolar — Main Street — Oregon City, Oregon**, continuing the Main Street furniture/household-goods business documented in late 1904. The advertisement does not print a numbered address.  
Confidence: Very High for Tolpolar operating on Main Street on 3 February 1905; Unresolved for the exact numbered address or a connection to modern 503, 505, or 507 Main.

## E-059 — Fifth Street Improvement Across Main Street, 1905
Type: Primary municipal notices published in newspaper  
Date: August–October 1905  
Sources: `S-072`  
Related record: `evidence/E-059-1905-fifth-main-street-improvement.md`  
Claims: Published Oregon City notices document 1905 improvement of **Fifth Street** from Railroad Avenue to Main Street and from Main Street to Water Street, including grading, crushed rock, sidewalks, concrete curbs, corner blocks, and drains, with later solicitation of bids for the work. This is direct physical/municipal context at the Fifth-and-Main intersection but does not identify business occupants or numbered storefronts.  
Confidence: Very High for the improvement limits and 1905 street-work context; None for 503/505/507 business occupancy from this source.

## E-060 — Preliminary Oregon City Street-Numbering System, 1905
Type: Primary newspaper / municipal-context evidence  
Date: 30 June 1905  
Sources: `S-074`  
Related record: `evidence/E-060-1905-preliminary-street-numbering.md`  
Claims: The 30 June 1905 *Oregon City Enterprise*, in connection with federal inspection for free mail delivery, urged residents to use a **system of numbering residences that had recently been introduced**. This establishes preliminary numbering by mid-1905, but later 1906 sources show that the City still needed to formalize the system through an ordinance, numbering plat, street signs, and mandatory implementation. The 1905 item therefore does not by itself prove that the later 501/503/505/507 Main sequence was already uniformly assigned or consistently used.  
Confidence: Very High for a preliminary numbering system by June 1905; Unresolved for exact mapping to the later 501/503/505/507 sequence.