# Source Register

## Source Trust Rule — Internal / Time Capsule Maps Material

Rodney Young is the creator/maintainer of Time Capsule Maps and the steward of this Main Street Archive. Internal project notes, Time Capsule Maps metadata, direct user corrections, and family/oral-history notes should be treated as trusted internal project sources for what they directly record. They should still be classified by evidence type and kept separate from primary documentary records such as deeds, Sanborn maps, permits, tax cards, newspaper articles, business licenses, OLCC records, and original photographs.

## S-024 — Morning Enterprise, 31 March 1912, H. H. Smith notice
URL: https://oregonnews.uoregon.edu/lccn/sn00063701/1912-03-31/ed-1/seq-4.pdf  
Related evidence: `E-023`  
Notes: Pool-hall license application at 503 Main.

## S-032 — Chicago Store advertisements, 1911-1913
URL: https://oregonnews.uoregon.edu/lccn/sn00063698/1911-04-14/ed-1/seq-7/ocr/  
Related evidence: `E-026`  
Notes: Primary advertisements place The Chicago Store at 505 Main. Also see `S-061` for its 5 January 1912 wording "Main St. just below Postoffice."

## S-059 — Oregon City Courier, 5 January 1912, H. P. Brightbill tea advertisement
Source: User-supplied photograph of newspaper advertisement in ChatGPT conversation, 20 August 2026.  
Publication/date: *Oregon City Courier*, 5 January 1912.  
Related evidence: `E-050`  
Notes: Advertisement reads **"H. P. BRIGHTBILL"**, **"509 Main St."**, **"Phone 74"**, **"OREGON CITY"**. Primary evidence for Brightbill at 509 Main on this date.

## S-060 — 1912 Post Office business-cluster advertisements
URL: Oregon Digital historic newspaper archive; individual page captures/URLs to be normalized when archived.  
Related evidence: `E-051`  
Related research note: `evidence/1912-main-street-postoffice-cluster.md`  
Notes: Contemporary business advertising places I. Tolpolar opposite the Post Office; M. E. Dunn near/next door to the P.O.; Schrader's Bakery near the Post Office; and Pioneer Transfer Co. in the Postoffice Building. Relative-location evidence does not by itself establish numbered addresses for Dunn, Schrader, or the Post Office.

## S-061 — Oregon City Courier, 5 January 1912, page 6 business advertisements
Canonical page URL: https://oregonnews.uoregon.edu/lccn/sn00063698/1912-01-05/ed-1/seq-6/  
Repository transcription: `newspapers/oregon-city-courier/1912-01-05-page-6-transcription.md`  
Repository PDF: `newspapers/oregon-city-courier/1912-01-05-page-6-main-street-ads.pdf`  
Original uploaded filename: `503 505-Chicago Store 507 509 511 527 Bailey_Price Oregon City Courier 1913.pdf` (the `1913` year in the upload filename was a typo; the page is 5 January 1912).  
Related evidence: `E-026`, `E-050`, `E-051`, `E-052`  
Notes: Page 6 advertisements include **The Chicago Store — "Main St. just below Postoffice"** (independently established at **505 Main** by `E-026`); **Bailey & Price, Billiard and Pool Parlors — 527 Main Street, Opposite Grand Theater**; **Clems Chop House — 5th and Main Street**; and **Wm. Gardner, Watchmaker and Jeweler — Main Near 8th**. H. P. Brightbill at **509 Main** is also documented from this issue (`S-059`).

## S-062 — City of Oregon City, Downtown Final Report, 2000
Canonical URL: https://www.orcity.org/DocumentCenter/View/4025/Downtown-Final-Report---2000-PDF  
Type: Official municipal historic-resource survey / secondary source.  
Relevant pages: p. 14 discusses later entrance alterations to the Swartz Building; summary table near the end of the report lists **527 Main St. — Swartz Building — 1935**.  
Related evidence: `E-053`  
Repository extract note: `records/historic-surveys/527-main-swartz-building-1935-source-note.md`  
Notes: The report classifies the Swartz Building as historic but not eligible in its then-current state and gives **1935** as the construction date. It also notes that the entrance had been altered after the earlier 1983 survey. The full external PDF was browser-verified on 20 August 2026; direct binary mirroring from the City endpoint was not available in the current tool environment, so the repository preserves the canonical URL and a verified source extract/provenance note.

## S-063 — ODOT / University of Oregon Museum of Natural & Cultural History, Cultural Resources Planning Document, 12 May 2021
Canonical URL: https://www.oregon.gov/odot/Projects/Project%20Documents/Cultural%20Resources%20Baseline%20Report_REDACTED%20VERSION.pdf  
Type: Official state cultural-resources planning report / secondary source.  
Relevant page: p. 16, Table 2.  
Related evidence: `E-053`; also resolves the current Harding Building replacement date question.  
Repository extract note: `records/historic-surveys/527-main-swartz-building-1935-source-note.md`  
Notes: Table 2 lists **527 Main St — Swartz Building — 1935**. The same table lists **507-511 Main St — Harding Building — 1968**, providing documentary support for the replacement-building date after the 1 September 1967 fire. Because the 2021 table likely draws in part on earlier inventory work, treat it as strong corroboration rather than necessarily a wholly independent original dating source. The external PDF was browser-verified on 20 August 2026; direct binary mirroring from the ODOT endpoint was not available in the current tool environment.

## S-064 — Oregon City Courier, 17 June 1915, Holman & Randall at Fifth and Main
Canonical PDF: https://oregonnews.uoregon.edu/lccn/sn00063698/1915-06-17/ed-1/seq-3.pdf  
Type: Primary newspaper advertisement.  
Related evidence: `E-054`  
Repository source capture: `evidence/source-captures/501-main-holman-1915-1921.md`  
Notes: Directly places R. L. Holman and T. P. Randall, undertakers, at **Fifth and Main St.** Does not print 501 Main. Original page PDF still needs physical mirroring.

## S-065 — Oregon City Courier, 2 March 1916, Holman & Randall at Fifth and Main
Canonical PDF: https://oregonnews.uoregon.edu/lccn/sn00063698/1916-03-02/ed-1/seq-9.pdf  
Type: Primary newspaper advertisement.  
Related evidence: `E-054`  
Repository source capture: `evidence/source-captures/501-main-holman-1915-1921.md`  
Notes: Repeats Holman and Randall at **Fifth and Main St.** Original page PDF still needs physical mirroring.

## S-066 — Oregon City Courier, 11 January 1917, R. L. Holman at Fifth and Main
Canonical PDF: https://oregonnews.uoregon.edu/lccn/sn00063698/1917-01-11/ed-1/seq-5.pdf  
Type: Primary newspaper advertisement.  
Related evidence: `E-054`  
Repository source capture: `evidence/source-captures/501-main-holman-1915-1921.md`  
Notes: Directly places R. L. Holman, leading undertaker, at **Fifth and Main St.** Original page PDF still needs physical mirroring.

## S-067 — Oregon City Courier, October–December 1918, Holman & Pace chapel / funeral parlors
Primary captured page: https://oregonnews.uoregon.edu/lccn/sn00063698/1918-10-24/ed-1/seq-1.pdf  
Type: Primary newspaper references.  
Related evidence: `E-055`  
Repository source capture: `evidence/source-captures/501-main-holman-1915-1921.md`  
Notes: Establishes Holman & Pace chapel/funeral-parlor business continuity in 1918. Recovered references do **not** give Fifth & Main or 501 Main. Original page binaries still need physical mirroring.

## S-068 — Eastern Clackamas News, 17 February 1921, Holman & Pace
Canonical PDF: https://oregonnews.uoregon.edu/lccn/sn96088133/1921-02-17/ed-1/seq-8.pdf  
Type: Primary newspaper advertisement.  
Related evidence: `E-055`  
Repository source capture: `evidence/source-captures/501-main-holman-1915-1921.md`  
Notes: Identifies Holman & Pace as undertakers, embalmers and funeral directors in Oregon City. No street address is printed in the recovered ad. Original page PDF still needs physical mirroring.

## S-069 — National Register nomination, DeWitt Clinton Latourette House, 1992
Canonical PDF: https://npgallery.nps.gov/GetAsset/152322a5-6e9f-44b2-8871-c4fef169dad0/  
Type: Official National Park Service documentation / secondary source lead.  
Relevant page: PDF p. 6.  
Related evidence: `E-056`  
Repository extract note: `records/historic-surveys/1992-latourette-house-1924-directory-citation-source-note.md`  
Notes: Bibliography cites **R. L. Polk and Company, Oregon City Directory, 1924**; same page identifies **Oregon City Planning Department** as the repository for additional data. The directory pages themselves are not reproduced. NPS PDF binary still needs physical mirroring if desired.

## S-070 — Oregon City Enterprise, I. Tolpolar advertisements, late 1904
Canonical pages:  
- https://oregonnews.uoregon.edu/lccn/sn00063700/1904-10-21/ed-1/seq-1/  
- https://oregonnews.uoregon.edu/lccn/sn00063700/1904-11-04/ed-1/seq-1/  
- https://oregonnews.uoregon.edu/lccn/sn00063700/1904-12-30/ed-1/seq-1/  
Type: Primary newspaper advertisements.  
Related evidence: `E-057`  
Repository binary: `newspapers/oregon-city-enterprise/1904-tolpolar-main-street-ad.pdf`  
Repository source capture: `evidence/source-captures/1904-1905-main-street-research.md`  
Notes: Directly places **I. Tolpolar** and his furniture/household-goods business on **Main Street, Oregon City** in late 1904. The verified advertisements do not give a numbered address. The exact issue/page represented by the existing repository PDF still needs reconciliation before attaching a specific publication date to that binary.

## S-071 — Oregon City Enterprise, 3 February 1905, I. Tolpolar advertisement
Canonical page: https://oregonnews.uoregon.edu/lccn/sn00063700/1905-02-03/ed-1/seq-1/  
Type: Primary newspaper advertisement.  
Related evidence: `E-058`  
Repository source capture: `evidence/source-captures/1904-1905-main-street-research.md`  
Notes: Places **I. Tolpolar — Main Street — Oregon City, Oregon** and advertises furniture, carpets, crockery, hardware, glassware, graniteware, and new/second-hand goods. No numbered address is printed.

## S-072 — Oregon City Enterprise, Fifth Street improvement notices, 1905
Canonical pages:  
- https://oregonnews.uoregon.edu/lccn/sn00063700/1905-08-25/ed-1/seq-7/  
- https://oregonnews.uoregon.edu/lccn/sn00063700/1905-10-13/ed-1/seq-6/  
Type: Primary municipal notices published in newspaper.  
Related evidence: `E-059`  
Repository source capture: `evidence/source-captures/1904-1905-main-street-research.md`  
Notes: Documents 1905 improvement work on **Fifth Street** from Railroad Avenue to Main Street and from Main Street to Water Street. This is block/intersection context only and does not identify a business occupant or numbered storefront.

## S-073 — Oregon and Washington Gazetteer and Business Directory, 1905–1906 — source lead
Type: Historical business-directory lead; underlying pages not yet inspected.  
Related research note: `evidence/source-captures/1904-1905-main-street-research.md`  
Notes: Catalog/search evidence identifies a 1905–1906 Oregon and Washington gazetteer/business directory available through FamilySearch. The viewer required sign-in during the research session, so no 503/505/507 occupant claim is made from it. Priority target is the Oregon City Main Street address/business listings.

## S-074 — Oregon City Enterprise, 30 June 1905, preliminary street-numbering / free-delivery report
Canonical page: https://oregonnews.uoregon.edu/lccn/sn00063700/1905-06-30/ed-1/seq-1/  
Type: Primary newspaper / municipal-context evidence.  
Related evidence: `E-060`  
Repository source capture: `evidence/source-captures/1904-1905-main-street-research.md`  
Notes: Reports that a system of numbering residences had recently been introduced and urges residents to number properties so federal inspection for free mail delivery can proceed. It does not reproduce an address plat and does not prove that the later 501/503/505/507 Main sequence was already uniformly assigned or consistently used.